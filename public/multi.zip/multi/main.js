$(document).ready(function(){
  var width = $('body').width()-70;


  function fitByWidth(width, images) {
    var s = width/1000;
    var height = 1500*s;

    var result = {width: width, height: height, images: []};

    for (var i = 0; i < images.length; i++) {
      var image = images[i];
      result.images.push({
        imageUrl: image.url,
        imageContainerLeft: image.left*s,
        imageContainerTop: image.top*s,
        imageContainerWidth: image.width*s,
        imageContainerHeight: image.height*s
      });
    };

    return result;
  }

  var images = [
    {
      url: 'http://pic.52mxp.com/site/girl2.png',
      left: 0,
      top: 0,
      width: 500,
      height: 750
    },
    {
      url: 'images/girl.jpg',
      left: 500,
      top: 0,
      width: 500,
      height: 750
    },
    {
      url: 'http://pic.52mxp.com/site/girl3.jpg',
      left: 0,
      top: 750,
      width: 500,
      height: 750
    },
    {
      url: 'http://pic.52mxp.com/site/1.jpg',
      left: 500,
      top: 750,
      width: 500,
      height: 750
    }
  ];

  var config = fitByWidth(width, images);

  window.card = new MultiImagesCard("#card", config);

  var left = ($('body').width() - width)/2;
  $('#card').css({left: left, top: 35});
});
